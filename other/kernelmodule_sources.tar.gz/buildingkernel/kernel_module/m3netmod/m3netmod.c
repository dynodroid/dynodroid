/* 
 * Machiry Aravind Kumar
 * Georgia Institute Of Technology
 * Atlanta, GA
 * amachiry@gatech.edu
 *
 */ 

#include <asm/unistd.h> 
#include <linux/autoconf.h> 
#include <linux/in.h> 
#include <linux/init_task.h> 
#include <linux/ip.h> 
#include <linux/kernel.h> 
#include <linux/kmod.h> 
#include <linux/mm.h> 
#include <linux/module.h> 
#include <linux/sched.h> 
#include <linux/skbuff.h> 
#include <linux/stddef.h> 
#include <linux/string.h> 
#include <linux/syscalls.h> 
#include <linux/tcp.h> 
#include <linux/types.h> 
#include <linux/unistd.h> 
#include <linux/version.h> 
#include <linux/workqueue.h> 
#include <linux/sched.h>
#include <asm/uaccess.h>


MODULE_AUTHOR("Machiry Aravind Kumar");
MODULE_DESCRIPTION("Network and File System call logging");

//asmlinkage long (*orig_bind) (int sockfd, struct sockaddr __user *addr, int addrlen);
asmlinkage long (*orig_connect) (int sockfd, struct sockaddr __user *addr, int addrlen);
asmlinkage long (*orig_accept) (int sockfd, struct sockaddr __user *addr, int __user *addrlen);
//asmlinkage long (*orig_accept4) (int sockfd, struct sockaddr __user *addr, int __user *addrlen, int flags);
asmlinkage long (*orig_listen) (int sockfd,int backlog);
asmlinkage long (*orig_open)(const char *pathname, int flags); 

//Thes are the global constants
//Module Name
char *moduleName= "M3_NET_Ker";

//sys_call_table start address
//How did i find this?
//browse to kernel root folder
//#grep sys_call_table System.map
//TADA!!!
unsigned long *sys_call_table = 0xc0024ee4;
unsigned long localIP = 16777343;

asmlinkage long 
m3_connect (int sockfd, struct sockaddr __user *addr, int addrlen) { 
        if(addr != NULL) {
                if (addr->sa_family == AF_INET) {
		        struct sockaddr_in *ipv4 = (struct sockaddr_in *)addr;
                        //Hack: to prevent flodding kernel buffer when interacting with hierarchy viewer
                        //Comment: Nasty Hack
                        if(ipv4->sin_addr.s_addr != localIP) {
                         printk("M3_NET_Ker_connect:uid=%d,gid=%d,euid=%d,egid=%d,sockfd=%d,addr=%pI4,port=%d,ip=%lu\n",current_uid(),current_gid(),current_euid(),current_egid(),sockfd,&ipv4->sin_addr.s_addr,ipv4->sin_port);
                        }
	        }else{
		        struct sockaddr_in6 *ipv6 = (struct sockaddr_in6 *)addr;
                         printk("M3_NET_Ker_connect:uid=%d,gid=%d,euid=%d,egid=%d,sockfd=%d,addr=%pI6,port=%d\n",current_uid(),current_gid(),current_euid(),current_egid(),sockfd,&ipv6->sin6_addr,ipv6->sin6_port);
   	        }                
        }
	return orig_connect(sockfd,addr,addrlen);
} 

//Function not used
/*asmlinkage long 
m3_bind(int sockfd, struct sockaddr __user *addr, int addrlen) { 
        if(addr != NULL) {
                if (addr->sa_family == AF_INET) {
		        struct sockaddr_in *ipv4 = (struct sockaddr_in *)addr;
		         printk("M3_NET_Ker_bind:uid=%d,gid=%d,euid=%d,egid=%d,sockfd=%d,addr=%pI4,port=%d\n,ip=%lu",current_uid(),current_gid(),current_euid(),current_egid(),sockfd,&ipv4->sin_addr.s_addr,ipv4->sin_port,ipv4->sin_addr.s_addr);
	        }else{
		        struct sockaddr_in6 *ipv6 = (struct sockaddr_in6 *)addr;
		        printk("M3_NET_Ker_bind:uid=%d,gid=%d,euid=%d,egid=%d,sockfd=%d,addr=%pI6,port=%d\n",current_uid(),current_gid(),current_euid(),current_egid(),sockfd,&ipv6->sin6_addr,ipv6->sin6_port);
   	        } 
        }
	return orig_bind(sockfd,addr,addrlen); 
} */

asmlinkage long 
m3_accept(int sockfd, struct sockaddr __user *addr, int __user *addrlen) { 
	long retVal = orig_accept(sockfd,addr,addrlen); 
        if(addr != NULL) {
                if (addr->sa_family == AF_INET) {
		        struct sockaddr_in *ipv4 = (struct sockaddr_in *)addr;
                        //nasty ip hack
                        if(ipv4->sin_addr.s_addr != localIP) {
                        printk("M3_NET_Ker_accept:uid=%d,gid=%d,euid=%d,egid=%d,sockfd=%d\n,addr=%pI4,port=%d\n",current_uid(),current_gid(),current_euid(),current_egid(),sockfd,&ipv4->sin_addr.s_addr,ipv4->sin_port);
                        }
	        } else{
                        struct sockaddr_in6 *ipv6 = (struct sockaddr_in6 *)addr;
		        printk("M3_NET_Ker_accept:uid=%d,gid=%d,euid=%d,egid=%d,sockfd=%d,addr=%pI6,port=%d\n",current_uid(),current_gid(),current_euid(),current_egid(),sockfd,&ipv6->sin6_addr,ipv6->sin6_port);
                }
        }
        return retVal;
}

asmlinkage long 
m3_listen(int sockfd,int backlog) {
        printk("M3_NET_Ker_listen:uid=%d,gid=%d,euid=%d,egid=%d,sockfd=%d,backlog=%d\n",current_uid(),current_gid(),current_euid(),current_egid(),sockfd,backlog);
        return orig_listen(sockfd,backlog);
} 

asmlinkage long 
m3_open(const char *pathname, int flags) { 
        //This is such a nasty hack! i tell u
        long retVal = orig_open(pathname,flags);
        if(current_uid() > 10000) {
                printk("M3_FILE_Ker_open: uid=%d,gid=%d,euid=%d,egid=%d,filepath=%s\n",current_uid(),current_gid(),current_euid(),current_egid(),pathname); 
        }
	return retVal; 
} 

/*asmlinkage long 
m3_accept4(int sockfd, struct sockaddr __user *addr, int __user *addrlen, int flags) { 
        if(addr != NULL) {
                if (addr->sa_family == AF_INET) {
		        struct sockaddr_in *ipv4 = (struct sockaddr_in *)addr;
		        portNumber = ipv4->sin_port;
		        return portNumber;
	        }else{
		        struct sockaddr_in6 *ipv6 = (struct sockaddr_in6 *)addr;
		        portNumber = ipv6->sin6_port;
		        return portNumber;
   	        } 
        }

	return orig_accept4(sockfd,addr,addrlen,flags); 
} */

static int __init 
m3mod_start (void) 
{ 
	       
        printk(KERN_INFO "trying to install %s android lkm, sys_call_table at:%p\n",moduleName,sys_call_table);

        //Here we just modify the system call table
        //to first point to the modified
        //system call , which logs the connect info using printk
	orig_connect = sys_call_table[__NR_connect]; 
	sys_call_table[__NR_connect] = m3_connect; 

	orig_accept = sys_call_table[__NR_accept]; 
	sys_call_table[__NR_accept] = m3_accept; 

        //Removed : Obvious: we dont want to fill up the kernel buffer by logging all binds.
	//orig_bind = sys_call_table[__NR_bind]; 
	//sys_call_table[__NR_bind] = m3_bind; 

        orig_listen = sys_call_table[__NR_listen]; 
	sys_call_table[__NR_listen] = m3_listen;

        orig_open = sys_call_table[__NR_open]; 
	sys_call_table[__NR_open] = m3_open; 

        printk(KERN_INFO "installed %s android lkm sucessfully.\n",moduleName);
	return 0; 
} 


static void __exit 
m3mod_stop (void) 
{ 
        printk(KERN_INFO "Trying to remove %s android lkm, sys_call_table at:%p\n",moduleName,sys_call_table);
        //Restore all the old entries
	sys_call_table[__NR_connect] = orig_connect; 
	sys_call_table[__NR_accept] = orig_accept; 

        //Removed : for the same reason above
	//sys_call_table[__NR_bind] = &orig_bind; 

	sys_call_table[__NR_listen] = orig_listen; 
        sys_call_table[__NR_open] = orig_open; 
        printk(KERN_INFO "removing %s android lkm\n",moduleName);
} 

module_init (m3mod_start); 
module_exit (m3mod_stop); 
