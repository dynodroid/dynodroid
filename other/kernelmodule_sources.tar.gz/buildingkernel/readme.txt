Resources:
        Android Kernel Versions : http://elinux.org/Android_Kernel_Versions
        Kernel Module Programing Guide: http://tldp.org/LDP/lkmpg/2.6/html/c976.html
        Android Linux Kernel Development Group : https://groups.google.com/forum/?hl=en&fromgroups#!forum/android-kernel
        DefCon 18 talk : this is not the droid you are looking for:
                Vedio: https://media.defcon.org/dc-18/video/DEF%20CON%2018%20Hacking%20Conference%20Presentation%20By%20-%20Nicholas%20J.%20Percoco%20and%20Christian%20Papathanasiou%20-%20This%20is%20Not%20the%20Droid%20You%20are%20Looking%20For%20-%20Video.m4v
                White Paper: https://www.defcon.org/images/defcon-18/dc-18-presentations/Trustwave-Spiderlabs/DEFCON-18-Trustwave-Spiderlabs-Android-Rootkit-WP.pdf

Basic Info:
        Kernel sources doesn't come with the android sources, we need to download them separetly.
        kernel-qemu is the kernal image that comes prebuilt in the android sources.
                usually it will be in relative path: prebuilt/android-arm/kernel/kernel-qemu
        
        Once we have our custom kernel image we can run the emulator with the custom image using '-kernel' option

Customizing the Kernel:

        1) Download the kernel:

                git clone https://android.googlesource.com/kernel/goldfish
                git checkout android-goldfish-2.6.29

        2) Do the required modifications to the kernel. 
                [For M3]: enable dynamic kernel module loading.
                        1) copy the config file present in kernel_config folder to root of kernel folder as .config .
                                cp kernel_config/config <kernel_sources>/.config                        

        3) building kernel :
                make ARCH=arm goldfish_defconfig
                make ARCH=arm CROSS_COMPILE=<path_to_downloaded_android_sources>/prebuilt/linux-x86/toolchain/arm-eabi-4.2.1/bin/arm-eabi-
        
        4) Booting emulator with the built kernel:
                after the compilation is sucessful, you will get the image file at: arch/arm/boot/zImage (under your kernel sources folder)
                emulator -avd <avd_Name> -kernel <pathToKernelSources>/arch/arm/boot/zImage -show-kernel
                
        
Why dynamic kernel modules? why not modify the linux kernel it self to log the system calls?
        No need to rebuild the entire kernel.
        Flexible way of adding clients, we dont need to recompile kernel every time, we want to monitor some system call.
        oblivious to changes in kernel.
        on demand monitoring, we can turn monitoring on and off.

Building LKM:
        copy all the contents of the folder : kernel_module to a different directory.
        Create your own file( say sample.c):
                1) Write code for the module in it. (for template refer : m3netmod.c )
                2) modify the first line of the make file to : obj-m += sample.o
                4) Modify the Makefile , to point to the correct location of tool chain and also to the correct location of android sdk.

                        CROSS_COMPILE=<rootOfTheAndroidSDKSources>/prebuilt/linux-x86/toolchain/arm-eabi-4.2.1/bin/arm-eabi-
                         KERNEL_DIR ?= <rootOfTheKernelSources>
                5) make clean
                6) make all ( this will create sample.ko)

        Testing :
                First push the built module (sample.ko) to teh device.
                1) adb push sample.ko /sdcard/sample.ko
                2) adb shell
                3) cd /sdcard
                4) insmod sample.ko
                5) [Verify] lsmod should list your module.
                        
        
        After you have done this: either use dmesg or emulator output to see your printk messages.
        

